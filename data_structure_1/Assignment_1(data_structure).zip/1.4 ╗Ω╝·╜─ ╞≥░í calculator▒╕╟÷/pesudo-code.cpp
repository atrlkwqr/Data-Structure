procedure caculator

if(pow){
	pos = pos + 3
		while(1){
			 prev.Push
			 val.Push
			 if([pos] == ')'){
			 	prev.GetTop
			 	val.GetTop
			 	pow(prev, val);
			 }
			 
		}
	}
if(log){
	pos = pos + 3
		while(1){
			 val.Push
			 if([pos] == ')'){
			 	val.GetTop
			 	log(val);
			 }
			 
		}
}
if(sqrt){
	pos = pos + 4
		while(1){
			 prev.Push
			 val.Push
			 if([pos] == ')'){
			 	prev.GetTop
			 	val.GetTop
			 	sqrt(prev, val);
			 }
			 
		}
}
else{
	if(digit?)
		digit.Push;
		
	else if(op?)
		op.Push;
		if([pos] == ')'){
			 	digit.prev.GetTop
			 	digit.val.GetTop
			 	op.val.GetTop
			 	
			 	return rev op val)
}
end procedure
